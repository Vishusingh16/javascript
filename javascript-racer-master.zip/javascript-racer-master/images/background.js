var BACKGROUND = {
  HILLS: { x:    5, y:    5, w: 1280, h:  480 },
  SKY:   { x:    5, y:  495, w: 1280, h:  480 },
  TREES: { x:    5, y:  985, w: 1280, h:  480 }
};
